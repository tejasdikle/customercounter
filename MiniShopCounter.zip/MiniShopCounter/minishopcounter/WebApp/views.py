from rest_framework import viewsets
from .models import Customer, Product, Employee
from .serializers import CustomerSerializer, ProductSerializer, EmployeeSerializer
from django.shortcuts import render
from django.http import HttpResponse


class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

